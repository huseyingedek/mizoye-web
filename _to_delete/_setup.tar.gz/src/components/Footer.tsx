"use client";

import Link from "next/link";
import { useLanguage } from "@/context/LanguageContext";
import { navItems, siteConfig } from "@/lib/site";
import Container from "./Container";
import {
  LinkedInIcon,
  TwitterIcon,
  InstagramIcon,
  GithubIcon,
  MailIcon,
  PhoneIcon,
} from "./Icons";

export default function Footer() {
  const { t } = useLanguage();
  const year = new Date().getFullYear();

  const socials = [
    { href: siteConfig.social.linkedin, label: "LinkedIn", Icon: LinkedInIcon },
    { href: siteConfig.social.twitter, label: "X", Icon: TwitterIcon },
    { href: siteConfig.social.instagram, label: "Instagram", Icon: InstagramIcon },
    { href: siteConfig.social.github, label: "GitHub", Icon: GithubIcon },
  ];

  return (
    <footer className="border-t border-slate-200 bg-slate-950 text-slate-300">
      <Container className="py-14">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          <div className="lg:col-span-1">
            <Link href="/" className="flex items-center gap-2">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-brand-600 via-magenta-500 to-accent-500 text-sm font-black text-white">
                M
              </span>
              <span className="text-lg font-bold text-white">
                {t.brand.name}
                <span className="text-brand-400"> {t.brand.suffix}</span>
              </span>
            </Link>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-slate-400">
              {t.footer.tagline}
            </p>
            <div className="mt-5 flex items-center gap-3">
              {socials.map(({ href, label, Icon }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/5 text-slate-300 transition-colors hover:border-brand-400 hover:text-white"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
              {t.footer.quickLinks}
            </h3>
            <ul className="mt-4 space-y-2.5">
              {navItems.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="text-sm text-slate-400 transition-colors hover:text-white"
                  >
                    {t.nav[item.key]}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
              {t.footer.solutions}
            </h3>
            <ul className="mt-4 space-y-2.5">
              {t.solutions.items.slice(0, 5).map((item) => (
                <li key={item.title}>
                  <Link
                    href="/cozumler"
                    className="text-sm text-slate-400 transition-colors hover:text-white"
                  >
                    {item.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white">
              {t.footer.contact}
            </h3>
            <ul className="mt-4 space-y-3">
              <li>
                <a
                  href={siteConfig.phoneHref}
                  className="flex items-center gap-2.5 text-sm text-slate-400 transition-colors hover:text-white"
                >
                  <PhoneIcon className="h-4 w-4 text-brand-400" />
                  {siteConfig.phone}
                </a>
              </li>
              <li>
                <a
                  href={siteConfig.emailHref}
                  className="flex items-center gap-2.5 text-sm text-slate-400 transition-colors hover:text-white"
                >
                  <MailIcon className="h-4 w-4 text-brand-400" />
                  {siteConfig.email}
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-white/10 pt-6 text-center text-sm text-slate-500">
          © {year} {t.brand.name} {t.brand.suffix}. {t.footer.rights}
        </div>
      </Container>
    </footer>
  );
}
