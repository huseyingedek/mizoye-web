import Link from "next/link";
import type { ReactNode } from "react";
import { ArrowRightIcon } from "./Icons";

export default function CtaButton({
  href,
  children,
  variant = "primary",
  withArrow = false,
}: {
  href: string;
  children: ReactNode;
  variant?: "primary" | "secondary";
  withArrow?: boolean;
}) {
  const styles =
    variant === "primary"
      ? "bg-gradient-to-r from-brand-600 to-brand-500 text-white shadow-lg shadow-brand-500/30 hover:scale-[1.03]"
      : "border border-slate-300 bg-white/70 text-slate-800 backdrop-blur hover:border-brand-400 hover:text-brand-700";

  return (
    <Link
      href={href}
      className={`inline-flex items-center justify-center gap-2 rounded-xl px-6 py-3 text-sm font-semibold transition-all duration-200 ${styles}`}
    >
      {children}
      {withArrow ? <ArrowRightIcon className="h-4 w-4" /> : null}
    </Link>
  );
}
