import type { ComponentType, SVGProps } from "react";
import {
  CodeIcon,
  MobileIcon,
  BuildingIcon,
  AiIcon,
  CloudIcon,
  DesignIcon,
} from "./Icons";

// Çeviri sözlüğündeki solutions.items sırasıyla eşleşen ikonlar.
export const solutionIcons: ComponentType<SVGProps<SVGSVGElement>>[] = [
  CodeIcon,
  MobileIcon,
  BuildingIcon,
  AiIcon,
  CloudIcon,
  DesignIcon,
];
