export type Lang = "tr" | "en";

export const translations = {
  tr: {
    meta: {
      title: "Mizoye Yazılım | Kurumsal Yazılım ve Dijital Çözümler",
      description:
        "Mizoye Yazılım; web, mobil, yapay zeka ve bulut çözümleriyle işletmelerin dijital dönüşümünü güçlendiren kurumsal bir yazılım şirketidir.",
    },
    brand: {
      name: "Mizoye",
      suffix: "Yazılım",
    },
    nav: {
      home: "Anasayfa",
      about: "Hakkımızda",
      solutions: "Çözümlerimiz",
      mission: "Misyon & Vizyon",
      contact: "İletişim",
      cta: "Teklif Alın",
    },
    home: {
      badge: "Dijital dönüşüm ortağınız",
      heroTitle: "Geleceğin yazılımını bugün inşa ediyoruz",
      heroSubtitle:
        "Mizoye Yazılım olarak; web, mobil, yapay zeka ve bulut teknolojileriyle işletmenizi bir adım öteye taşıyan ölçeklenebilir ve güvenilir çözümler geliştiriyoruz.",
      ctaPrimary: "Projenizi Konuşalım",
      ctaSecondary: "Çözümlerimizi Keşfedin",
      stats: [
        { value: "120+", label: "Tamamlanan Proje" },
        { value: "50+", label: "Mutlu Kurumsal Müşteri" },
        { value: "8+", label: "Yıllık Tecrübe" },
        { value: "%99.9", label: "Sistem Erişilebilirliği" },
      ],
      solutionsTitle: "Uçtan uca dijital çözümler",
      solutionsSubtitle:
        "Fikir aşamasından canlıya alma sürecine kadar ihtiyaç duyduğunuz tüm teknoloji hizmetlerini tek bir çatı altında sunuyoruz.",
      whyTitle: "Neden Mizoye?",
      whySubtitle:
        "Sadece kod yazmıyoruz; işinizi büyüten sürdürülebilir dijital ürünler tasarlıyoruz.",
      why: [
        {
          title: "Uzman Ekip",
          text: "Alanında deneyimli yazılım mühendisleri, tasarımcılar ve danışmanlardan oluşan güçlü bir kadro.",
        },
        {
          title: "Ölçeklenebilir Mimari",
          text: "Büyüyen iş hacminize uyum sağlayan, modern ve sağlam yazılım mimarileri kuruyoruz.",
        },
        {
          title: "Şeffaf Süreç",
          text: "Her aşamada net iletişim, düzenli raporlama ve öngörülebilir teslimat.",
        },
        {
          title: "7/24 Destek",
          text: "Canlıya aldıktan sonra da yanınızdayız; kesintisiz bakım ve teknik destek.",
        },
      ],
      processTitle: "Çalışma Sürecimiz",
      processSubtitle: "Netlik ve kaliteyi merkeze alan, kanıtlanmış bir yöntem.",
      process: [
        {
          step: "01",
          title: "Keşif & Analiz",
          text: "İhtiyaçlarınızı dinliyor, hedefleri ve kapsamı birlikte netleştiriyoruz.",
        },
        {
          step: "02",
          title: "Tasarım & Planlama",
          text: "Kullanıcı deneyimini ve teknik mimariyi kurgulayıp yol haritasını çıkarıyoruz.",
        },
        {
          step: "03",
          title: "Geliştirme & Test",
          text: "Çevik yöntemlerle geliştirir, her adımda kalite kontrolü uygularız.",
        },
        {
          step: "04",
          title: "Yayına Alma & Destek",
          text: "Ürününüzü canlıya alır, sürekli izleme ve iyileştirme ile büyütürüz.",
        },
      ],
      finalCtaTitle: "Dijital dönüşümünüze birlikte başlayalım",
      finalCtaText:
        "Projeniz hakkında konuşmak ve size özel bir çözüm planı oluşturmak için bizimle iletişime geçin.",
      finalCtaButton: "Hemen İletişime Geçin",
    },
    about: {
      badge: "Hakkımızda",
      title: "Teknolojiyle değer üreten bir ekip",
      lead: "Mizoye Yazılım, işletmelerin dijital hedeflerine ulaşmasına yardımcı olmak için kurulmuş, yenilikçi ve güvenilir bir yazılım şirketidir.",
      paragraphs: [
        "Kuruluşumuzdan bu yana; sağlık, finans, e-ticaret, lojistik ve üretim başta olmak üzere birçok sektörde faaliyet gösteren kurumlara özel yazılım çözümleri sunuyoruz. Her projeye, müşterimizin iş hedeflerini kendi hedeflerimiz gibi benimseyerek yaklaşıyoruz.",
        "Ekibimiz; deneyimli yazılım mühendisleri, ürün tasarımcıları, veri uzmanları ve proje yöneticilerinden oluşuyor. Modern teknolojileri ve kanıtlanmış mühendislik pratiklerini bir araya getirerek hem bugünün ihtiyaçlarına cevap veren hem de geleceğe hazır ürünler geliştiriyoruz.",
        "Bizim için başarı; yalnızca teslim edilen bir proje değil, müşterilerimizle kurduğumuz uzun soluklu güven ilişkisidir.",
      ],
      valuesTitle: "Değerlerimiz",
      valuesSubtitle: "Yaptığımız her işin temelinde bu ilkeler yatıyor.",
      values: [
        {
          title: "Kalite Odaklılık",
          text: "En yüksek standartlarda, sürdürülebilir ve güvenilir yazılımlar geliştirmeyi ilke ediniyoruz.",
        },
        {
          title: "Yenilikçilik",
          text: "Sürekli öğrenerek en güncel teknolojileri projelerinize taşıyoruz.",
        },
        {
          title: "Şeffaflık",
          text: "Açık iletişim ve dürüstlük, müşteri ilişkilerimizin temelini oluşturur.",
        },
        {
          title: "Müşteri Memnuniyeti",
          text: "Beklentilerin ötesine geçmek için çözüm ortağı gibi çalışıyoruz.",
        },
        {
          title: "Takım Ruhu",
          text: "Birlikte üreterek daha güçlü ve yaratıcı sonuçlar ortaya koyuyoruz.",
        },
        {
          title: "Sorumluluk",
          text: "Verdiğimiz her sözün ve yazdığımız her satırın arkasında dururuz.",
        },
      ],
    },
    solutions: {
      badge: "Çözümlerimiz",
      title: "İşinizi büyüten teknoloji çözümleri",
      lead: "İhtiyaçlarınıza özel, ölçeklenebilir ve güvenli yazılım hizmetleriyle dijital dönüşümünüzün her aşamasında yanınızdayız.",
      items: [
        {
          title: "Web Uygulama Geliştirme",
          text: "Modern, hızlı ve SEO uyumlu kurumsal web siteleri ve web uygulamaları geliştiriyoruz.",
          features: ["Kurumsal web siteleri", "Yönetim panelleri", "E-ticaret platformları"],
        },
        {
          title: "Mobil Uygulama Geliştirme",
          text: "iOS ve Android için native ve cross-platform performanslı mobil uygulamalar.",
          features: ["iOS & Android", "Cross-platform", "Uygulama bakımı"],
        },
        {
          title: "Kurumsal Yazılım (ERP/CRM)",
          text: "İş süreçlerinizi dijitalleştiren, verimliliği artıran özel kurumsal yazılımlar.",
          features: ["Süreç otomasyonu", "ERP & CRM", "Entegrasyonlar"],
        },
        {
          title: "Yapay Zeka & Veri Analitiği",
          text: "Verinizi anlamlı içgörülere dönüştüren yapay zeka ve makine öğrenimi çözümleri.",
          features: ["Tahminleme modelleri", "Chatbot & LLM", "Veri görselleştirme"],
        },
        {
          title: "Bulut & DevOps",
          text: "Ölçeklenebilir bulut altyapıları, CI/CD hatları ve kesintisiz operasyon.",
          features: ["Bulut mimarisi", "CI/CD otomasyonu", "İzleme & güvenlik"],
        },
        {
          title: "UI/UX Tasarım & Danışmanlık",
          text: "Kullanıcı odaklı arayüz tasarımı ve dijital ürün strateji danışmanlığı.",
          features: ["Kullanıcı araştırması", "Arayüz tasarımı", "Ürün stratejisi"],
        },
      ],
    },
    mission: {
      badge: "Misyon & Vizyon",
      title: "Teknolojide yön veren bir vizyon",
      lead: "Yolculuğumuza yön veren temel amaç ve geleceğe dair hedeflerimiz.",
      missionTitle: "Misyonumuz",
      missionText:
        "İşletmelerin dijital dönüşüm yolculuğunda güvenilir çözüm ortağı olmak; yenilikçi, ölçeklenebilir ve kullanıcı odaklı yazılımlar geliştirerek müşterilerimize sürdürülebilir değer katmak.",
      visionTitle: "Vizyonumuz",
      visionText:
        "Türkiye'den dünyaya açılan, teknolojiyi insanların ve kurumların yararına dönüştüren, sektöründe öncü ve referans gösterilen bir yazılım şirketi olmak.",
      goalsTitle: "Bizi Yönlendiren İlkeler",
      goals: [
        {
          title: "Sürekli Gelişim",
          text: "Ekibimizi ve teknolojimizi durmaksızın geliştirerek en iyi çözümleri sunmak.",
        },
        {
          title: "Uzun Vadeli İş Birliği",
          text: "Müşterilerimizle güvene dayalı, kalıcı ilişkiler kurmak.",
        },
        {
          title: "Toplumsal Katkı",
          text: "Teknolojiyi topluma ve çevreye fayda sağlayacak şekilde kullanmak.",
        },
      ],
    },
    contact: {
      badge: "İletişim",
      title: "Bizimle iletişime geçin",
      lead: "Projeniz, sorularınız veya iş birliği talepleriniz için bize ulaşın. Ekibimiz en kısa sürede size geri dönüş yapacaktır.",
      phoneTitle: "Telefon",
      emailTitle: "E-posta",
      addressTitle: "Adres",
      addressValue: "Maslak Mah. Teknoloji Cad. No:1, Sarıyer / İstanbul",
      hoursTitle: "Çalışma Saatleri",
      hoursValue: "Pazartesi – Cuma, 09:00 – 18:00",
      socialTitle: "Bizi takip edin",
    },
    footer: {
      tagline: "İşletmenizin dijital dönüşüm ortağı.",
      quickLinks: "Hızlı Bağlantılar",
      solutions: "Çözümler",
      contact: "İletişim",
      rights: "Tüm hakları saklıdır.",
    },
  },
  en: {
    meta: {
      title: "Mizoye Software | Enterprise Software & Digital Solutions",
      description:
        "Mizoye Software is an enterprise software company empowering businesses' digital transformation with web, mobile, AI and cloud solutions.",
    },
    brand: {
      name: "Mizoye",
      suffix: "Software",
    },
    nav: {
      home: "Home",
      about: "About Us",
      solutions: "Solutions",
      mission: "Mission & Vision",
      contact: "Contact",
      cta: "Get a Quote",
    },
    home: {
      badge: "Your digital transformation partner",
      heroTitle: "We build the software of the future, today",
      heroSubtitle:
        "At Mizoye Software, we craft scalable and reliable solutions with web, mobile, AI and cloud technologies to take your business one step further.",
      ctaPrimary: "Let's Talk About Your Project",
      ctaSecondary: "Explore Our Solutions",
      stats: [
        { value: "120+", label: "Completed Projects" },
        { value: "50+", label: "Happy Enterprise Clients" },
        { value: "8+", label: "Years of Experience" },
        { value: "99.9%", label: "System Uptime" },
      ],
      solutionsTitle: "End-to-end digital solutions",
      solutionsSubtitle:
        "From the idea stage to going live, we deliver every technology service you need under a single roof.",
      whyTitle: "Why Mizoye?",
      whySubtitle:
        "We don't just write code; we design sustainable digital products that grow your business.",
      why: [
        {
          title: "Expert Team",
          text: "A strong team of experienced software engineers, designers and consultants.",
        },
        {
          title: "Scalable Architecture",
          text: "We build modern, robust software architectures that adapt to your growing workload.",
        },
        {
          title: "Transparent Process",
          text: "Clear communication, regular reporting and predictable delivery at every stage.",
        },
        {
          title: "24/7 Support",
          text: "We stay by your side after launch with uninterrupted maintenance and technical support.",
        },
      ],
      processTitle: "Our Process",
      processSubtitle: "A proven method that puts clarity and quality at the center.",
      process: [
        {
          step: "01",
          title: "Discovery & Analysis",
          text: "We listen to your needs and clarify goals and scope together.",
        },
        {
          step: "02",
          title: "Design & Planning",
          text: "We shape the user experience and technical architecture and draw the roadmap.",
        },
        {
          step: "03",
          title: "Development & Testing",
          text: "We develop with agile methods and apply quality control at every step.",
        },
        {
          step: "04",
          title: "Launch & Support",
          text: "We take your product live and grow it with continuous monitoring and improvement.",
        },
      ],
      finalCtaTitle: "Let's start your digital transformation together",
      finalCtaText:
        "Get in touch with us to discuss your project and build a solution plan tailored to you.",
      finalCtaButton: "Contact Us Now",
    },
    about: {
      badge: "About Us",
      title: "A team creating value through technology",
      lead: "Mizoye Software is an innovative and reliable software company founded to help businesses achieve their digital goals.",
      paragraphs: [
        "Since our founding, we have delivered custom software solutions to organizations across many industries, primarily healthcare, finance, e-commerce, logistics and manufacturing. We approach every project by embracing our client's business goals as our own.",
        "Our team consists of experienced software engineers, product designers, data specialists and project managers. By combining modern technologies with proven engineering practices, we build products that meet today's needs and are ready for the future.",
        "For us, success is not just a delivered project, but the long-lasting relationship of trust we build with our clients.",
      ],
      valuesTitle: "Our Values",
      valuesSubtitle: "These principles lie at the heart of everything we do.",
      values: [
        {
          title: "Quality Focus",
          text: "We are committed to developing sustainable and reliable software at the highest standards.",
        },
        {
          title: "Innovation",
          text: "We continuously learn and bring the latest technologies to your projects.",
        },
        {
          title: "Transparency",
          text: "Open communication and honesty form the basis of our client relationships.",
        },
        {
          title: "Customer Satisfaction",
          text: "We work like a solution partner to exceed expectations.",
        },
        {
          title: "Team Spirit",
          text: "By creating together, we deliver stronger and more creative results.",
        },
        {
          title: "Responsibility",
          text: "We stand behind every promise we make and every line we write.",
        },
      ],
    },
    solutions: {
      badge: "Our Solutions",
      title: "Technology solutions that grow your business",
      lead: "We are with you at every stage of your digital transformation with scalable and secure software services tailored to your needs.",
      items: [
        {
          title: "Web Application Development",
          text: "We build modern, fast and SEO-friendly corporate websites and web applications.",
          features: ["Corporate websites", "Admin dashboards", "E-commerce platforms"],
        },
        {
          title: "Mobile App Development",
          text: "High-performance native and cross-platform mobile apps for iOS and Android.",
          features: ["iOS & Android", "Cross-platform", "App maintenance"],
        },
        {
          title: "Enterprise Software (ERP/CRM)",
          text: "Custom enterprise software that digitizes your business processes and boosts efficiency.",
          features: ["Process automation", "ERP & CRM", "Integrations"],
        },
        {
          title: "AI & Data Analytics",
          text: "AI and machine learning solutions that turn your data into meaningful insights.",
          features: ["Predictive models", "Chatbot & LLM", "Data visualization"],
        },
        {
          title: "Cloud & DevOps",
          text: "Scalable cloud infrastructures, CI/CD pipelines and uninterrupted operations.",
          features: ["Cloud architecture", "CI/CD automation", "Monitoring & security"],
        },
        {
          title: "UI/UX Design & Consulting",
          text: "User-centered interface design and digital product strategy consulting.",
          features: ["User research", "Interface design", "Product strategy"],
        },
      ],
    },
    mission: {
      badge: "Mission & Vision",
      title: "A vision that shapes technology",
      lead: "The core purpose that guides our journey and our goals for the future.",
      missionTitle: "Our Mission",
      missionText:
        "To be a reliable solution partner in businesses' digital transformation journey; to add sustainable value to our clients by developing innovative, scalable and user-centered software.",
      visionTitle: "Our Vision",
      visionText:
        "To be a pioneering and reference software company that expands from Türkiye to the world, transforming technology for the benefit of people and organizations.",
      goalsTitle: "The Principles That Guide Us",
      goals: [
        {
          title: "Continuous Improvement",
          text: "Constantly developing our team and technology to deliver the best solutions.",
        },
        {
          title: "Long-Term Collaboration",
          text: "Building trust-based, lasting relationships with our clients.",
        },
        {
          title: "Social Contribution",
          text: "Using technology in ways that benefit society and the environment.",
        },
      ],
    },
    contact: {
      badge: "Contact",
      title: "Get in touch with us",
      lead: "Reach out for your projects, questions or collaboration requests. Our team will get back to you as soon as possible.",
      phoneTitle: "Phone",
      emailTitle: "Email",
      addressTitle: "Address",
      addressValue: "Maslak Mah. Teknoloji Cad. No:1, Sarıyer / Istanbul",
      hoursTitle: "Working Hours",
      hoursValue: "Monday – Friday, 09:00 – 18:00",
      socialTitle: "Follow us",
    },
    footer: {
      tagline: "Your business's digital transformation partner.",
      quickLinks: "Quick Links",
      solutions: "Solutions",
      contact: "Contact",
      rights: "All rights reserved.",
    },
  },
};

export type Translation = (typeof translations)["tr"];
