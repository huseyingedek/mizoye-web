"use client";

import { useLanguage } from "@/context/LanguageContext";
import Container from "@/components/Container";
import PageHero from "@/components/PageHero";
import CtaButton from "@/components/CtaButton";
import { solutionIcons } from "@/components/solutionIcons";
import { CheckIcon } from "@/components/Icons";

export default function SolutionsPage() {
  const { t } = useLanguage();

  return (
    <>
      <PageHero
        badge={t.solutions.badge}
        title={t.solutions.title}
        lead={t.solutions.lead}
      />

      <section className="py-16 sm:py-20">
        <Container>
          <div className="grid gap-6 md:grid-cols-2">
            {t.solutions.items.map((item, i) => {
              const Icon = solutionIcons[i] ?? solutionIcons[0];
              return (
                <div
                  key={item.title}
                  className="card-hover flex flex-col rounded-2xl border border-slate-200 bg-white p-8"
                >
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-600 via-brand-500 to-accent-500 text-white shadow-lg shadow-brand-500/25">
                    <Icon className="h-7 w-7" />
                  </div>
                  <h2 className="mt-6 text-xl font-bold text-slate-900">
                    {item.title}
                  </h2>
                  <p className="mt-3 text-sm leading-relaxed text-slate-600">
                    {item.text}
                  </p>
                  <ul className="mt-5 space-y-2.5 border-t border-slate-100 pt-5">
                    {item.features.map((feature) => (
                      <li
                        key={feature}
                        className="flex items-center gap-2.5 text-sm text-slate-700"
                      >
                        <CheckIcon className="h-4 w-4 shrink-0 text-brand-600" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </Container>
      </section>

      <section className="pb-24">
        <Container>
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand-700 via-brand-600 to-magenta-500 px-8 py-14 text-center shadow-2xl shadow-brand-500/30 sm:py-16">
            <div className="pointer-events-none absolute -right-10 -top-10 h-48 w-48 rounded-full bg-white/10 blur-2xl" />
            <h2 className="relative text-2xl font-bold text-white sm:text-3xl">
              {t.home.finalCtaTitle}
            </h2>
            <p className="relative mx-auto mt-3 max-w-xl text-sm text-brand-100 sm:text-base">
              {t.home.finalCtaText}
            </p>
            <div className="relative mt-7 flex justify-center">
              <CtaButton href="/iletisim" variant="secondary" withArrow>
                {t.home.finalCtaButton}
              </CtaButton>
            </div>
          </div>
        </Container>
      </section>
    </>
  );
}
