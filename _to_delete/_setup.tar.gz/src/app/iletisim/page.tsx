"use client";

import { useLanguage } from "@/context/LanguageContext";
import { siteConfig } from "@/lib/site";
import Container from "@/components/Container";
import PageHero from "@/components/PageHero";
import {
  PhoneIcon,
  MailIcon,
  MapPinIcon,
  ClockIcon,
  LinkedInIcon,
  TwitterIcon,
  InstagramIcon,
  GithubIcon,
} from "@/components/Icons";

export default function ContactPage() {
  const { t } = useLanguage();

  const cards = [
    {
      title: t.contact.phoneTitle,
      value: siteConfig.phone,
      href: siteConfig.phoneHref,
      Icon: PhoneIcon,
    },
    {
      title: t.contact.emailTitle,
      value: siteConfig.email,
      href: siteConfig.emailHref,
      Icon: MailIcon,
    },
    {
      title: t.contact.addressTitle,
      value: t.contact.addressValue,
      href: undefined,
      Icon: MapPinIcon,
    },
    {
      title: t.contact.hoursTitle,
      value: t.contact.hoursValue,
      href: undefined,
      Icon: ClockIcon,
    },
  ];

  const socials = [
    { href: siteConfig.social.linkedin, label: "LinkedIn", Icon: LinkedInIcon },
    { href: siteConfig.social.twitter, label: "X", Icon: TwitterIcon },
    { href: siteConfig.social.instagram, label: "Instagram", Icon: InstagramIcon },
    { href: siteConfig.social.github, label: "GitHub", Icon: GithubIcon },
  ];

  return (
    <>
      <PageHero
        badge={t.contact.badge}
        title={t.contact.title}
        lead={t.contact.lead}
      />

      <section className="py-16 sm:py-20">
        <Container>
          <div className="grid gap-6 sm:grid-cols-2">
            {cards.map(({ title, value, href, Icon }) => {
              const content = (
                <>
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-brand-600 to-accent-500 text-white shadow-lg shadow-brand-500/20">
                    <Icon className="h-6 w-6" />
                  </div>
                  <h3 className="mt-5 text-sm font-semibold uppercase tracking-wider text-slate-500">
                    {title}
                  </h3>
                  <p className="mt-1.5 text-lg font-semibold text-slate-900">
                    {value}
                  </p>
                </>
              );
              return href ? (
                <a
                  key={title}
                  href={href}
                  className="card-hover block rounded-2xl border border-slate-200 bg-white p-7"
                >
                  {content}
                </a>
              ) : (
                <div
                  key={title}
                  className="rounded-2xl border border-slate-200 bg-white p-7"
                >
                  {content}
                </div>
              );
            })}
          </div>

          {/* Sosyal medya */}
          <div className="mt-10 rounded-3xl bg-gradient-to-br from-brand-700 via-brand-600 to-magenta-500 px-8 py-10 text-center shadow-2xl shadow-brand-500/30">
            <h3 className="text-xl font-bold text-white">
              {t.contact.socialTitle}
            </h3>
            <div className="mt-6 flex flex-wrap items-center justify-center gap-4">
              {socials.map(({ href, label, Icon }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="flex h-12 w-12 items-center justify-center rounded-xl border border-white/20 bg-white/10 text-white backdrop-blur transition-transform hover:scale-110"
                >
                  <Icon className="h-5 w-5" />
                </a>
              ))}
            </div>
          </div>
        </Container>
      </section>
    </>
  );
}
