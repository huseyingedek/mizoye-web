"use client";

import { useLanguage } from "@/context/LanguageContext";
import Container from "@/components/Container";
import PageHero from "@/components/PageHero";
import SectionHeading from "@/components/SectionHeading";
import { ArrowRightIcon, CheckIcon } from "@/components/Icons";

export default function MissionPage() {
  const { t } = useLanguage();

  return (
    <>
      <PageHero
        badge={t.mission.badge}
        title={t.mission.title}
        lead={t.mission.lead}
      />

      <section className="py-16 sm:py-20">
        <Container>
          <div className="grid gap-6 lg:grid-cols-2">
            <div className="relative overflow-hidden rounded-3xl border border-brand-100 bg-gradient-to-br from-brand-50 to-white p-9">
              <div className="pointer-events-none absolute -right-8 -top-8 h-40 w-40 rounded-full bg-brand-200/40 blur-2xl" />
              <div className="relative">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-600 to-brand-500 text-white shadow-lg shadow-brand-500/25">
                  <ArrowRightIcon className="h-6 w-6" />
                </div>
                <h2 className="mt-6 text-2xl font-bold text-slate-900">
                  {t.mission.missionTitle}
                </h2>
                <p className="mt-4 text-base leading-relaxed text-slate-600">
                  {t.mission.missionText}
                </p>
              </div>
            </div>

            <div className="relative overflow-hidden rounded-3xl border border-magenta-400/20 bg-gradient-to-br from-magenta-400/10 to-white p-9">
              <div className="pointer-events-none absolute -right-8 -top-8 h-40 w-40 rounded-full bg-magenta-400/20 blur-2xl" />
              <div className="relative">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-magenta-500 to-accent-500 text-white shadow-lg shadow-magenta-500/25">
                  <CheckIcon className="h-6 w-6" />
                </div>
                <h2 className="mt-6 text-2xl font-bold text-slate-900">
                  {t.mission.visionTitle}
                </h2>
                <p className="mt-4 text-base leading-relaxed text-slate-600">
                  {t.mission.visionText}
                </p>
              </div>
            </div>
          </div>
        </Container>
      </section>

      <section className="bg-slate-50 py-20 sm:py-24">
        <Container>
          <SectionHeading title={t.mission.goalsTitle} />
          <div className="mt-14 grid gap-6 md:grid-cols-3">
            {t.mission.goals.map((goal, i) => (
              <div
                key={goal.title}
                className="rounded-2xl border border-slate-200 bg-white p-7 text-center"
              >
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-brand-600 to-accent-500 text-lg font-bold text-white">
                  {i + 1}
                </div>
                <h3 className="mt-5 text-lg font-bold text-slate-900">
                  {goal.title}
                </h3>
                <p className="mt-2.5 text-sm leading-relaxed text-slate-600">
                  {goal.text}
                </p>
              </div>
            ))}
          </div>
        </Container>
      </section>
    </>
  );
}
