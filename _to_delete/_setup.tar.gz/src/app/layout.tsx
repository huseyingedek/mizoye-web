import type { Metadata } from "next";
import { GeistSans } from "geist/font/sans";
import "./globals.css";
import { LanguageProvider } from "@/context/LanguageContext";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: {
    default: "Mizoye Yazılım | Kurumsal Yazılım ve Dijital Çözümler",
    template: "%s | Mizoye Yazılım",
  },
  description:
    "Mizoye Yazılım; web, mobil, yapay zeka ve bulut çözümleriyle işletmelerin dijital dönüşümünü güçlendiren kurumsal bir yazılım şirketidir.",
  keywords: [
    "yazılım şirketi",
    "web geliştirme",
    "mobil uygulama",
    "yapay zeka",
    "dijital dönüşüm",
    "kurumsal yazılım",
    "Mizoye",
  ],
  openGraph: {
    title: "Mizoye Yazılım | Kurumsal Yazılım ve Dijital Çözümler",
    description:
      "Web, mobil, yapay zeka ve bulut çözümleriyle işletmenizin dijital dönüşüm ortağı.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="tr" className={GeistSans.variable}>
      <body className="antialiased">
        <LanguageProvider>
          <div className="flex min-h-screen flex-col">
            <Navbar />
            <main className="flex-1">{children}</main>
            <Footer />
          </div>
        </LanguageProvider>
      </body>
    </html>
  );
}
